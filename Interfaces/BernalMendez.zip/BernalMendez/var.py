global ui
global calendar
global calendar2
global salir
global acercade
global dlgabrir
global bbdd
global Baja
global Bajacli
global report
global Altafact
version = '0.0.1rc'
