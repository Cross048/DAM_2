global ui
global calendar
global salir
global acercade
global dlgabrir
global bbdd
version = '0.0.1rc'
